PATCH_LIB("libanogs.so", "0x300", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3F8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x5D8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x430", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CD0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CFC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x51C8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0xFDBC0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x2F4134","\xC0\x03\x5F\xD6");//10 year online 
PATCH_LIB("libanogs.so","0x2F41F8","\xC0\x03\x5F\xD6");//10 year offline 
PATCH_LIB("libanogs.so","0x330490","\xC0\x03\x5F\xD6");//10 year offline 
PATCH_LIB("libanogs.so","0x39F568","\xC0\x03\x5F\xD6");// termination fix
PATCH_LIB("libanogs.so","0x49A9FC","\xC0\x03\x5F\xD6");//termination fix 
PATCH_LIB("libanogs.so","0x49AA38","\xC0\x03\x5F\xD6");//1 day fix
PATCH_LIB("libanogs.so","0x4B5E44","\xC0\x03\x5F\xD6");//1 day fix
MemoryPatch::createWithHex("libanogs.so",0x228560,"C0 03 5F D6").Modify(); // case 37
MemoryPatch::createWithHex("libanogs.so",0x2ece70,"C0 03 5F D6").Modify(); // 10y fix
MemoryPatch::createWithHex("libanogs.so",0x51FA80,"00 00 80 D2 C0 03 5F D6").Modify(); // crash fix
PATCH_LIB("libUE4.so", "0x73220CC", "00 00 80 D2 C0 03 5F D6"); // termination fix
MemoryPatch::createWithHex("libUE4.so", 0x6083C10, "1F 20 03 D5").Modify();//termination fix all case

 64bit (4.2.0)